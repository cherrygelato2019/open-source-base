#pragma once

	namespace function {
		void load_aimbot();
	}
