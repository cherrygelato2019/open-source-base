#include "../thread_entites.hpp"
#include "../../../vars/vars.h"
#include "../../../../um/um.h"
#include "../../../../src/functions/init_cheat/offsets/offsets.h"
void functions::entites::third_person() {

}