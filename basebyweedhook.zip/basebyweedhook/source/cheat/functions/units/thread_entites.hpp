#pragma once

namespace functions {
	namespace units {
		void thread();
	}

	namespace entites {
		void third_person();
	}
}