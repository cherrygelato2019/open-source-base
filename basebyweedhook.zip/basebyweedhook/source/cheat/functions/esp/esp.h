#pragma once
#include <iostream>

namespace visuals {
	namespace init {
		void Load_1();
	}
}
// fonts
