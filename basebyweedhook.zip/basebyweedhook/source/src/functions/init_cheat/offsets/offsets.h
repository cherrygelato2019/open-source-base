/*
Roblox version: version-31fc142272764f02 (LIVE)
Dumper version: 3dc59d1
Dumped at: 18:16 16/09/2025
Total offsets: 168

*/

#include <cstdint>
namespace Offsets {
    namespace AnimationTrack {
        inline constexpr uintptr_t Animation = 0xd8;
        inline constexpr uintptr_t Animator = 0x120;
        inline constexpr uintptr_t IsPlaying = 0x365;
        inline constexpr uintptr_t Looped = 0xfd;
        inline constexpr uintptr_t Speed = 0xec;
    }

    namespace BasePart {
        inline constexpr uintptr_t AssemblyAngularVelocity = 0x16c;
        inline constexpr uintptr_t AssemblyLinearVelocity = 0x160;
        inline constexpr uintptr_t Color3 = 0x1c4;
        inline constexpr uintptr_t Material = 0x2b8;
        inline constexpr uintptr_t Position = 0x154;
        inline constexpr uintptr_t Primitive = 0x178;
        inline constexpr uintptr_t PrimitiveFlags = 0x2e5;
        inline constexpr uintptr_t PrimitiveOwner = 0x278;
        inline constexpr uintptr_t Rotation = 0x130;
        inline constexpr uintptr_t Shape = 0x1e1;
        inline constexpr uintptr_t Size = 0x23c;
        inline constexpr uintptr_t Transparency = 0xf8;
        inline constexpr uintptr_t ValidatePrimitive = 0x6;
    }

    namespace ByteCode {
        inline constexpr uintptr_t Pointer = 0x10;
        inline constexpr uintptr_t Size = 0x20;
    }

    namespace Camera {
        inline constexpr uintptr_t CameraSubject = 0xf0;
        inline constexpr uintptr_t CameraType = 0x160;
        inline constexpr uintptr_t FieldOfView = 0x168;
        inline constexpr uintptr_t Position = 0x124;
        inline constexpr uintptr_t Rotation = 0x100;
    }

    namespace ClickDetector {
        inline constexpr uintptr_t MaxActivationDistance = 0x108;
        inline constexpr uintptr_t MouseIcon = 0xe8;
    }

    namespace DataModel {
        inline constexpr uintptr_t CreatorId = 0x190;
        inline constexpr uintptr_t GameId = 0x198;
        inline constexpr uintptr_t GameLoaded = 0x688;
        inline constexpr uintptr_t JobId = 0x140;
        inline constexpr uintptr_t PlaceId = 0x1a0;
        inline constexpr uintptr_t PlaceVersion = 0x1bc;
        inline constexpr uintptr_t PrimitiveCount = 0x4c8;
        inline constexpr uintptr_t ScriptContext = 0x3d0;
        inline constexpr uintptr_t ServerIP = 0x670;
        inline constexpr uintptr_t Workspace = 0x180;
    }

    namespace FakeDataModel {
        inline constexpr uintptr_t Pointer = 0x70a86b8;
        inline constexpr uintptr_t RealDataModel = 0x1c0;
    }

    namespace GuiObject {
        inline constexpr uintptr_t BackgroundColor3 = 0x508;
        inline constexpr uintptr_t BorderColor3 = 0x514;
        inline constexpr uintptr_t Image = 0xa18;
        inline constexpr uintptr_t LayoutOrder = 0x544;
        inline constexpr uintptr_t Position = 0x4d8;
        inline constexpr uintptr_t RichText = 0xab0;
        inline constexpr uintptr_t Rotation = 0x190;
        inline constexpr uintptr_t ScreenGui_Enabled = 0x48c;
        inline constexpr uintptr_t Size = 0x4f8;
        inline constexpr uintptr_t Text = 0xe08;
        inline constexpr uintptr_t TextColor3 = 0xeb8;
        inline constexpr uintptr_t Visible = 0x571;
    }

    namespace Humanoid {
        inline constexpr uintptr_t AutoRotate = 0x1e1;
        inline constexpr uintptr_t Health = 0x19c;
        inline constexpr uintptr_t HipHeight = 0x1a8;
        inline constexpr uintptr_t HumanoidState = 0x870;
        inline constexpr uintptr_t HumanoidStateID = 0x20;
        inline constexpr uintptr_t JumpHeight = 0x1b4;
        inline constexpr uintptr_t JumpPower = 0x1b8;
        inline constexpr uintptr_t MaxHealth = 0x1bc;
        inline constexpr uintptr_t MaxSlopeAngle = 0x1c0;
        inline constexpr uintptr_t RigType = 0x1d0;
        inline constexpr uintptr_t Walkspeed = 0x1dc;
        inline constexpr uintptr_t WalkspeedCheck = 0x3b8;
    }

    namespace Instance {
        inline constexpr uintptr_t AttributeContainer = 0x38;
        inline constexpr uintptr_t AttributeList = 0x18;
        inline constexpr uintptr_t AttributeToNext = 0x58;
        inline constexpr uintptr_t AttributeToValue = 0x18;
        inline constexpr uintptr_t ChildrenEnd = 0x8;
        inline constexpr uintptr_t ChildrenStart = 0x68;
        inline constexpr uintptr_t ClassDescriptor = 0x18;
        inline constexpr uintptr_t ClassName = 0x8;
        inline constexpr uintptr_t Name = 0x88;
        inline constexpr uintptr_t Parent = 0x58;
        inline constexpr uintptr_t PropertiesEnd = 0x40;
        inline constexpr uintptr_t PropertiesStart = 0x38;
    }

    namespace Lighting {
        inline constexpr uintptr_t Ambient = 0xe0;
        inline constexpr uintptr_t Brightness = 0x128;
        inline constexpr uintptr_t ClockTime = 0x1c0;
        inline constexpr uintptr_t ColorShift_Bottom = 0xf8;
        inline constexpr uintptr_t ColorShift_Top = 0xec;
        inline constexpr uintptr_t ExposureCompensation = 0x134;
        inline constexpr uintptr_t FogColor = 0x104;
        inline constexpr uintptr_t FogEnd = 0x13c;
        inline constexpr uintptr_t FogStart = 0x140;
        inline constexpr uintptr_t GeographicLatitude = 0x198;
        inline constexpr uintptr_t OutdoorAmbient = 0x110;
    }

    namespace LocalScript {
        inline constexpr uintptr_t ByteCode = 0x1b0;
        inline constexpr uintptr_t Hash = 0x1c0;
    }

    namespace MeshPart {
        inline constexpr uintptr_t MeshId = 0x2d8;
        inline constexpr uintptr_t Texture = 0x308;
    }

    namespace Misc {
        inline constexpr uintptr_t Adornee = 0x110;
        inline constexpr uintptr_t AnimationId = 0xd8;
        inline constexpr uintptr_t StringLength = 0x10;
        inline constexpr uintptr_t Value = 0xd8;
    }

    namespace Model {
        inline constexpr uintptr_t PrimaryPart = 0x268;
        inline constexpr uintptr_t Scale = 0x174;
    }

    namespace ModuleScript {
        inline constexpr uintptr_t ByteCode = 0x158;
        inline constexpr uintptr_t Hash = 0x170;
    }

    namespace MouseService {
        inline constexpr uintptr_t InputObject = 0x108;
        inline constexpr uintptr_t MousePosition = 0xf4;
        inline constexpr uintptr_t SensitivityPointer = 0x711ba20;
    }

    namespace Player {
        inline constexpr uintptr_t CameraMode = 0x2e0;
        inline constexpr uintptr_t Country = 0xf8;
        inline constexpr uintptr_t DisplayName = 0x118;
        inline constexpr uintptr_t Gender = 0xe00;
        inline constexpr uintptr_t LocalPlayer = 0x128;
        inline constexpr uintptr_t MaxZoomDistance = 0x2d8;
        inline constexpr uintptr_t MinZoomDistance = 0x2dc;
        inline constexpr uintptr_t ModelInstance = 0x348;
        inline constexpr uintptr_t Mouse = 0xca8;
        inline constexpr uintptr_t Team = 0x258;
        inline constexpr uintptr_t UserId = 0x280;
    }

    namespace PlayerMouse {
        inline constexpr uintptr_t Icon = 0xe8;
        inline constexpr uintptr_t Workspace = 0x170;
    }

    namespace PrimitiveFlags {
        inline constexpr uintptr_t Anchored = 0x2;
        inline constexpr uintptr_t CanCollide = 0x8;
        inline constexpr uintptr_t CanTouch = 0x10;
    }

    namespace ProximityPrompt {
        inline constexpr uintptr_t ActionText = 0xd8;
        inline constexpr uintptr_t Enabled = 0x15e;
        inline constexpr uintptr_t GamepadKeyCode = 0x144;
        inline constexpr uintptr_t HoldDuration = 0x148;
        inline constexpr uintptr_t KeyCode = 0x14c;
        inline constexpr uintptr_t MaxActivationDistance = 0x150;
        inline constexpr uintptr_t ObjectText = 0xf8;
        inline constexpr uintptr_t RequiresLineOfSight = 0x15f;
    }

    namespace RenderView {
        inline constexpr uintptr_t DeviceD3D11 = 0x8;
        inline constexpr uintptr_t VisualEngine = 0x10;
    }

    namespace RunService {
        inline constexpr uintptr_t HeartbeatFPS = 0xc0;
        inline constexpr uintptr_t HeartbeatTask = 0x100;
        inline constexpr uintptr_t PhysicsJob = 0xf0;
    }

    namespace Sky {
        inline constexpr uintptr_t MoonAngularSize = 0x224;
        inline constexpr uintptr_t MoonTextureId = 0xe0;
        inline constexpr uintptr_t SkyboxBk = 0x108;
        inline constexpr uintptr_t SkyboxDn = 0x130;
        inline constexpr uintptr_t SkyboxFt = 0x158;
        inline constexpr uintptr_t SkyboxLf = 0x180;
        inline constexpr uintptr_t SkyboxOrientation = 0x218;
        inline constexpr uintptr_t SkyboxRt = 0x1a8;
        inline constexpr uintptr_t SkyboxUp = 0x1d0;
        inline constexpr uintptr_t StarCount = 0x228;
        inline constexpr uintptr_t SunAngularSize = 0x21c;
        inline constexpr uintptr_t SunTextureId = 0x1f8;
    }

    namespace SpecialMesh {
        inline constexpr uintptr_t MeshId = 0x110;
        inline constexpr uintptr_t Scale = 0x174;
    }

    namespace StatsItem {
        inline constexpr uintptr_t Value = 0xd0;
    }

    namespace TaskScheduler {
        inline constexpr uintptr_t FakeDataModelToDataModel = 0x1b0;
        inline constexpr uintptr_t JobEnd = 0x1d8;
        inline constexpr uintptr_t JobName = 0x18;
        inline constexpr uintptr_t JobStart = 0x1d0;
        inline constexpr uintptr_t MaxFPS = 0x1b0;
        inline constexpr uintptr_t Pointer = 0x7171238;
        inline constexpr uintptr_t RenderJobToFakeDataModel = 0x38;
        inline constexpr uintptr_t RenderJobToRenderView = 0x218;
    }

    namespace Team {
        inline constexpr uintptr_t BrickColor = 0xd8;
    }

    namespace Textures {
        inline constexpr uintptr_t Decal_Texture = 0x1a0;
        inline constexpr uintptr_t Texture_Texture = 0x1a0;
    }

    namespace VisualEngine {
        inline constexpr uintptr_t Dimensions = 0x720;
        inline constexpr uintptr_t Pointer = 0x6e061b0;
        inline constexpr uintptr_t ToDataModel1 = 0x700;
        inline constexpr uintptr_t ToDataModel2 = 0x1c0;
        inline constexpr uintptr_t ViewMatrix = 0x4b0;
    }

    namespace Workspace {
        inline constexpr uintptr_t CurrentCamera = 0x450;
        inline constexpr uintptr_t DistributedGameTime = 0x470;
        inline constexpr uintptr_t Gravity = 0x1ac;
        inline constexpr uintptr_t GravityContainer = 0x3d8;
        inline constexpr uintptr_t PrimitivesPointer1 = 0x3d8;
        inline constexpr uintptr_t PrimitivesPointer2 = 0x210;
        inline constexpr uintptr_t ReadOnlyGravity = 0x998;
    }

}