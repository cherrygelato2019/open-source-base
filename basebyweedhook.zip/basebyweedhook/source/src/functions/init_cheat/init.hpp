#pragma once
#include <iostream>
#include "../../../um/um.h"
#include "../../../cheat/vars/console/console.h"
#include "../../../cheat/vars/vars.h"
#include "offsets/offsets.h"
#include "../../../cheat/overlay/design/utils/overlay.h"

namespace init {
	namespace cheat {
		void load();
		void find_stuff();

	}
}
